import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import database.db_connection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        double price = Double.parseDouble(request.getParameter("price"));
        int stock = Integer.parseInt(request.getParameter("stock"));
        int categoryId = Integer.parseInt(request.getParameter("category_id"));
        String imageUrl = request.getParameter("image_url");

        Connection con = null;
        PreparedStatement pst = null;

        try {
            con = db_connection.getConnection(); // ✅ Use your db_connection class

            String sql = "INSERT INTO products (name, description, price, stock, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?)";
            pst = con.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, description);
            pst.setDouble(3, price);
            pst.setInt(4, stock);
            pst.setInt(5, categoryId);
            pst.setString(6, imageUrl);

            pst.executeUpdate();

            // Redirect to the product listing page
            response.sendRedirect("view_products.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("admin/error.jsp"); // Optional: add error page
        } finally {
            try { if (pst != null) pst.close(); } catch (Exception e) { e.printStackTrace(); }
            try { if (con != null) con.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }
}
