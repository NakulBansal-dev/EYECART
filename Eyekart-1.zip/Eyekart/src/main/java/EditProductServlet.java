import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import database.db_connection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/EditProductServlet")
public class EditProductServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.sendRedirect("edit_product.jsp"); // or show a message, or redirect to a safe page
	}

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int productId = Integer.parseInt(request.getParameter("product_id"));
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        double price = Double.parseDouble(request.getParameter("price"));
        int stock = Integer.parseInt(request.getParameter("stock"));
        int categoryId = Integer.parseInt(request.getParameter("category_id"));
        String imageUrl = request.getParameter("image_url");

        Connection con = null;
        PreparedStatement pst = null;

        try {
            con = db_connection.getConnection(); // ✅ Use your db_connection class

            String sql = "UPDATE products SET name=?, description=?, price=?, stock=?, category_id=?, image_url=? WHERE product_id=?";
            pst = con.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, description);
            pst.setDouble(3, price);
            pst.setInt(4, stock);
            pst.setInt(5, categoryId);
            pst.setString(6, imageUrl);
            pst.setInt(7, productId);

            pst.executeUpdate();

            response.sendRedirect("view_products.jsp"); // Redirect after successful update
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("admin/error.jsp"); // Optional: Redirect to an error page
        } finally {
            try { if (pst != null) pst.close(); } catch (Exception e) { e.printStackTrace(); }
            try { if (con != null) con.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }
}
