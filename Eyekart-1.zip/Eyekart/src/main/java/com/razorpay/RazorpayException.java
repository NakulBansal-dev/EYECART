package com.razorpay;

public class RazorpayException {

}
