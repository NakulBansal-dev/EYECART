package com.razorpay;

public class RazorpayClient {

	public static final String Orders = null;

}
