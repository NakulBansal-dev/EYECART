import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import database.db_connection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/EditCategoryServlet")
public class EditCategoryServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int category_id = Integer.parseInt(request.getParameter("category_id"));
        String category_name = request.getParameter("category_name");

        try {
            Connection con = db_connection.getConnection();
            PreparedStatement pst = con.prepareStatement("UPDATE categories SET category_name=? WHERE category_id=?");
            pst.setString(1, category_name);
            pst.setInt(2, category_id);
            pst.executeUpdate();
            response.sendRedirect("view_categories.jsp?success=Category Updated");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("view_categories.jsp?error=Category Not Updated");
        }
    }
}
