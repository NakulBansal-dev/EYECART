import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import database.db_connection;

public class ProductDAO {

    public static List<String> getProductsByCategoryId(int categoryId) {
        List<String> productList = new ArrayList<>();
        try {
            Connection con = db_connection.getConnection(); // Using your existing connection class

            String sql = "SELECT name FROM products WHERE category_id = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, categoryId);

            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                productList.add(rs.getString("name")); // Adjust column name if different
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return productList;
    }
}
