import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import database.db_connection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/AddCategoryServlet")
public class AddCategoryServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String category_name = request.getParameter("category_name");

        try {
            Connection con = db_connection.getConnection();
            PreparedStatement pst = con.prepareStatement("INSERT INTO categories(category_name) VALUES(?)");
            pst.setString(1, category_name);
            pst.executeUpdate();
            response.sendRedirect("view_categories.jsp?success=Category Added");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("view_categories.jsp?error=Category Not Added");
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.sendRedirect("view_categories.jsp?error=Invalid Request");
    }  
}
