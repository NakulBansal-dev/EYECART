

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

// Ensure the servlet URL mapping matches your project structure
@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("admin_login.jsp"); // Change to your actual JSP file name
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password"); // This is plain text

        System.out.println("Entered Username: " + username);
        System.out.println("Entered Password: " + password); // Debugging

        try {
            // Load JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to Database
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/lenskart_clone", "root", "");

            // SQL Query to get the password from database
            PreparedStatement ps = con.prepareStatement("SELECT password FROM admin WHERE username=?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("password");
                System.out.println("Stored Password: " + storedPassword); // Debugging

                // Compare passwords directly (Plain Text)
                if (password.equals(storedPassword)) {
                    System.out.println("Password Matched! Logging in...");
                    
                    // Create session
                    HttpSession session = request.getSession();
                    session.setAttribute("username", username);
                    
                    response.sendRedirect("adminDashboard.jsp");
                    return;
                } else {
                    System.out.println("Password does NOT match.");
                }
            } else {
                System.out.println("User not found.");
            }

            // If credentials are invalid
            response.sendRedirect("admin_login.jsp?error=Invalid Credentials");

            // Close connection
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("admin_login.jsp?error=An error occurred");
        }
    }
}