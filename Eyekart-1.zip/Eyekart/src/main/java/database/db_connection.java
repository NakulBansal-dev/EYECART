
package database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class db_connection {
    private static final String URL = "jdbc:mysql://localhost:3306/lenskart_clone?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String USER = "root"; // Default XAMPP/WAMP user
    private static final String PASSWORD = ""; // Default is empty in XAMPP/WAMP
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName(DRIVER); // Load MySQL driver
            con = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Database Connected Successfully!");
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver Not Found! " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Database Connection Failed! " + e.getMessage());
        }
        return con;
    }
}