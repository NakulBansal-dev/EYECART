package org.json;

public class JSONObject {

}
