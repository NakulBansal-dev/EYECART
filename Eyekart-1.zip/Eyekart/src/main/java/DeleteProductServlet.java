import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import database.db_connection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DeleteProductServlet")
public class DeleteProductServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int productId = Integer.parseInt(request.getParameter("id"));

        Connection con = null;
        PreparedStatement pst = null;

        try {
            con = db_connection.getConnection(); // ✅ Use your db_connection class

            String sql = "DELETE FROM products WHERE product_id = ?";
            pst = con.prepareStatement(sql);
            pst.setInt(1, productId);
            pst.executeUpdate();

            response.sendRedirect("view_products.jsp"); // Redirect to product list
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("admin/error.jsp"); // Optional: Redirect to an error page
        } finally {
            try { if (pst != null) pst.close(); } catch (Exception e) { e.printStackTrace(); }
            try { if (con != null) con.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    }
}
