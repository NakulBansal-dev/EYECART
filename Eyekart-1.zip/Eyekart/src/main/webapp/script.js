
 console.log("JS started");

document.addEventListener("DOMContentLoaded", function () {
  let slideIndex = 0;
  let slides = document.getElementsByClassName("slideSize");

  function showSlides(n) {
    if (n >= slides.length) {
      slideIndex = 0;
    }
    if (n < 0) {
      slideIndex = slides.length - 1;
    }

    for (let slide of slides) {
      slide.style.display = "none";
    }
    slides[slideIndex].style.display = "block";
  }

  function changeSlide(n) {
    slideIndex += n;
    showSlides(slideIndex);
  }

  function startAutoSlide() {
    setInterval(() => {
      changeSlide(1);
    }, 3000);
  }
  document.querySelector(".prev").addEventListener("click", () =>changeSlide(-1));
  document.querySelector(".next").addEventListener("click", () =>changeSlide(1));

  showSlides(slideIndex);
  startAutoSlide();
});